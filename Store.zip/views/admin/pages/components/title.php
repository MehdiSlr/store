<?php
// $sql = "SELECT * FROM settings";
// $result = $conn->query($sql);
// $row = $result->fetch_assoc();

// $title = $row['title'];
// $logo_url = $row['logo_url'];
?>
<a class="navbar-brand m-0" href="/" target="_blank">
<img src="../images/favicon.png" class="navbar-brand-img h-100" alt="main_logo">
<span class="ms-1 font-weight-bold text-white">GIFTOS</span>
</a>