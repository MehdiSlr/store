<?php
$server = "localhost";
$user = "root";
$pass = "";
$db = "store";
$conn = mysqli_connect($server, $user, $pass, $db);
?>